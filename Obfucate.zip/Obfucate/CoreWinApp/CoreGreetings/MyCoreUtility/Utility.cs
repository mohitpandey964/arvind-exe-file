﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyCoreUtility
{
    public static class Utility
    {
        public static string SayGoodMorning(string name)
        {
            return $"Good Morning! { name }";
        }

        public static string SayGoodBye(string name)
        {
            return $"Good Bye! { name }";
        }
    }
}
