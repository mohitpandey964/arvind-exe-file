﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MyCoreUtility;

namespace WinFormsApp1
{
    public partial class MyCoreGreetingsForm : Form
    {
        public MyCoreGreetingsForm()
        {
            InitializeComponent();
        }

        private void btnGoodMorning_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Utility.SayGoodMorning(txtName.Text.Trim()));
        }

        private void BtnGoodBye_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Utility.SayGoodBye(txtName.Text.Trim()));
        }
    }
}
