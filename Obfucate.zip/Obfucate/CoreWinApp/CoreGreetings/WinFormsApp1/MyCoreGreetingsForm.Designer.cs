﻿
namespace WinFormsApp1
{
    partial class MyCoreGreetingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGoodMorning = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.BtnGoodBye = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGoodMorning
            // 
            this.btnGoodMorning.Location = new System.Drawing.Point(33, 103);
            this.btnGoodMorning.Name = "btnGoodMorning";
            this.btnGoodMorning.Size = new System.Drawing.Size(121, 23);
            this.btnGoodMorning.TabIndex = 0;
            this.btnGoodMorning.Text = "Say Good Morning";
            this.btnGoodMorning.UseVisualStyleBackColor = true;
            this.btnGoodMorning.Click += new System.EventHandler(this.btnGoodMorning_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter your name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(33, 47);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(292, 23);
            this.txtName.TabIndex = 2;
            // 
            // BtnGoodBye
            // 
            this.BtnGoodBye.Location = new System.Drawing.Point(204, 103);
            this.BtnGoodBye.Name = "BtnGoodBye";
            this.BtnGoodBye.Size = new System.Drawing.Size(121, 23);
            this.BtnGoodBye.TabIndex = 3;
            this.BtnGoodBye.Text = "Say Good Bye";
            this.BtnGoodBye.UseVisualStyleBackColor = true;
            this.BtnGoodBye.Click += new System.EventHandler(this.BtnGoodBye_Click);
            // 
            // MyCoreGreetingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(355, 156);
            this.Controls.Add(this.BtnGoodBye);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnGoodMorning);
            this.Name = "MyCoreGreetingsForm";
            this.Text = "MyCoreGreetingsForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGoodMorning;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button BtnGoodBye;
    }
}