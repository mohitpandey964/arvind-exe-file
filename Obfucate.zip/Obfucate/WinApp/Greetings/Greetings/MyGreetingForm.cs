﻿using System;
using System.Windows.Forms;
using MyUtilities;


namespace Greetings
{
    public partial class MyGreetingForm : Form
    {
        public MyGreetingForm()
        {
            InitializeComponent();
        }

        private void btnGoodMorning_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Utility.SayGoodMoring(txtName.Text.Trim()));
        }

        private void btnGoodBye_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Utility.SayGoodBye(txtName.Text.Trim()));
        }
    }
}
