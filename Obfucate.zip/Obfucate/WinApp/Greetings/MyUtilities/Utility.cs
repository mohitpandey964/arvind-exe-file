﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyUtilities
{
    public static class Utility
    {
        public static string SayGoodMoring(string name)
        {
            return $"Good Morning! { name }";
        }

        public static string SayGoodBye(string name)
        {
            return $"Good Bye! { name }";
        }
    }
}
